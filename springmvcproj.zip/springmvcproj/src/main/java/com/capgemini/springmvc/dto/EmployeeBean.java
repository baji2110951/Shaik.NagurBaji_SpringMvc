package com.capgemini.springmvc.dto;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;
@Data
@SuppressWarnings("source")
public class EmployeeBean implements Serializable{
	 int empId;

	String empName;
     int age;
     double salary;
     String designation;
     String password;
     
}
